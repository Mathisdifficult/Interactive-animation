(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [
		{name:"转盘2017_1_atlas_", frames: [[642,968,272,42],[0,0,1000,966],[0,968,640,910]]}
];


// symbols:



(lib._2708556c5756e11a31 = function() {
	this.spriteSheet = ss["转盘2017_1_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.zhuanpan = function() {
	this.spriteSheet = ss["转盘2017_1_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.diskMC = function() {
	this.spriteSheet = ss["转盘2017_1_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.stop_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.text = new cjs.Text("stop", "22px 'Times New Roman'", "#FF0000");
	this.text.lineHeight = 0;
	this.text.lineWidth = 38;
	this.text.parent = this;
	this.text.setTransform(11.3,2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0033").ss(1,1,1).p("AEsAAQAABHhQAzQgEADgEACQhXA1h9AAQh8AAhYg1QhXg0AAhLQAAhKBXg1QBYg0B8AAQB9AABXA0QAEADAEACQBQA0AABGg");
	this.shape.setTransform(30,18);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF66").s().p("AjUB/QhXg0AAhLQAAhKBXg1QBZg0B7AAQB9AABXA0IAIAGQBQAzAABGQAABHhQAzIgIAFQhXA1h9AAQh7AAhZg1g");
	this.shape_1.setTransform(30,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,62,38);


(lib.start_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.text = new cjs.Text("start", "22px 'Times New Roman'", "#CC0000");
	this.text.lineHeight = 0;
	this.text.lineWidth = 41;
	this.text.parent = this;
	this.text.setTransform(11,3.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0033").ss(1,1,1).p("AEsAAQAABHhYAxQhXAyh9AAQh8AAhYgyQhXgxAAhHQAAhGBXgyQBYgxB8AAQB9AABXAxQBYAyAABGg");
	this.shape.setTransform(30,17.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF66").s().p("AjUB4QhXgyAAhGQAAhFBXgzQBZgxB7AAQB9AABXAxQBYAzAABFQAABGhYAyQhXAyh9AAQh7AAhZgyg");
	this.shape_1.setTransform(30,17.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.2,62,36);


(lib.diskMC1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.zhuanpan();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.306,0.305);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.diskMC1, new cjs.Rectangle(0,0,306,295), null);


(lib.Arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2708556c5756e11a31();
	this.instance.parent = this;
	this.instance.setTransform(-7,9.1,0.434,0.381,-90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Arrow, new cjs.Rectangle(-7,-109,16,118.1), null);


// stage content:
(lib.转盘2017_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var speed = 20; //速度
		var istart = false; //是否开始
		var rounds = 2; //圈数
		var totalAngle; //总的角度
		var currentAngle; //当前角度
		var targetAngle = 36; //目标角度
		var totalTime; //总的次数
		var perSpeed; //每一次的递减的加速度
		var mainStage = this;
		var mCount = 0;
		var angleArray = [90,180,310];
		
		var ZhuanPan = new lib.diskMC();
		var jiantou = new lib.Arrow();
		//var start_Btn = new lib.start_btn();
		//var stop_Btn = new lib.stop_btn();
		mainStage.addChild(ZhuanPan);
		mainStage.addChild(jiantou);
		//mainStage.addChild(start_Btn);
		//mainStage.addChild(stop_Btn);
		
		
		ZhuanPan.x = 30;
		ZhuanPan.y = 60;
		jiantou.x = (lib.properties.width)/2-20;
		jiantou.y = (lib.properties.height)/2+40;
		/*start_Btn.x = 350;
		start_Btn.y = 20;
		stop_Btn.x = 450;
		stop_Btn.y = 20;*/
		console.log("stage.canvas.height:"+stage.canvas.height);
		
		//mainStage.start_Btn.addEventListener("click", Start_Btn_ClickHandler.bind(mainStage));
		//mainStage.stop_Btn.addEventListener("click", Stop_Btn_ClickHandler.bind(mainStage));
		mainStage.addEventListener("tick",Run.bind(mainStage));
		
		this.start_btn.addEventListener("click", Start_Btn_ClickHandler.bind(this));
		this.stop_btn.addEventListener("click", Stop_Btn_ClickHandler.bind(this));
		function Start_Btn_ClickHandler()
		{
			if(istart)
				return;
			istart = true;
			setParameters();
		}
		function setParameters()
		{
			speed = 40; //速度
			rounds = 4; //圈数
			currentAngle = jiantou.rotation % 360;  //当前角度
			//targetAngle =  Math.floor(Math.random() * 9) * 36+18;; //目标角度
			var rand =Math.random();
			if(rand <= 0.8)
				targetAngle =  angleArray[0];
			else if(rand <= 0.95)
				targetAngle =  angleArray[1];
			else if(rand <= 0.99)
				targetAngle =  angleArray[2];
			else
				targetAngle =  angleArray[3];	
			//targetAngle =  angleArray[Math.floor(Math.random() * 4)]; //目标角度
			
			totalAngle = (360 * rounds) + (targetAngle - currentAngle); //算出总的角度
			//计算项数Sn=(a1+an)*n/2 
			//等差数列，算出n列次数
			//算出项数
			totalTime = ((2 * totalAngle) / speed);
		
			//d=(an-a1)÷（n-1）
			//算出公差
			perSpeed = (speed / (totalTime - 1));
			}
		function Stop_Btn_ClickHandler()
		{
			istart = false;
		}
		
		function StartGame()
		{
			
			
			}
		
		function StopAll()
		{
			mCount ++
			
			if(mCount ==120)
			{
				mCount =0;
				istart = true;
				setParameters();
				}
			
			}
		
		function Run(){
			if( istart)
			{
				jiantou.rotation += speed;
				speed -= perSpeed;
				if(speed<=0)
					istart = false;
				}
				else
					StopAll();
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.stop_btn = new lib.stop_btn();
	this.stop_btn.parent = this;
	this.stop_btn.setTransform(415,18.5);
	new cjs.ButtonHelper(this.stop_btn, 0, 1, 1);

	this.start_btn = new lib.start_btn();
	this.start_btn.parent = this;
	this.start_btn.setTransform(351.5,17.7);
	new cjs.ButtonHelper(this.start_btn, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.start_btn},{t:this.stop_btn}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(700.5,517.5,125.5,38);
// library properties:
lib.properties = {
	width: 700,
	height: 1000,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/转盘2017_1_atlas_.png?1509856461046", id:"转盘2017_1_atlas_"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;